package com.mecanica.model;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;
public class TrocaOleoTest {

    @Test
    public void testGettersEConstrutor() {
        TrocaOleo troca = new TrocaOleo("ABC1D23", 50.0, "5W30", 4);

        assertEquals("ABC1D23", troca.getPlacaVeiculo());
        assertEquals(50.0, troca.getValorBase(), 0.001);
        assertEquals("5W30", troca.getTipoOleo());
        assertEquals(4, troca.getLitros());
    }

    @Test
    public void testSetters() {
        TrocaOleo troca = new TrocaOleo("ABC1D23", 50.0, "5W30", 4);

        troca.setTipoOleo("10W40");
        troca.setLitros(5);
        troca.setValorBase(80.0);

        assertEquals("10W40", troca.getTipoOleo());
        assertEquals(5, troca.getLitros());
        assertEquals(80.0, troca.getValorBase(), 0.001);
    }

    @Test
    public void testValorBaseNegativoNoSetter() {
        TrocaOleo troca = new TrocaOleo("ABC1D23", 50.0, "5W30", 4);

        assertThrows(IllegalArgumentException.class, () -> troca.setValorBase(-10.0));
        assertEquals(50.0, troca.getValorBase(), 0.001);
    }

    @Test
    public void testValorBaseNegativoNoConstrutor() {
        assertThrows(IllegalArgumentException.class,
                () -> new TrocaOleo("ABC1D23", -1.0, "5W30", 4));
    }

    @Test
    public void testCalcularOrcamentoFinal() {
        TrocaOleo troca = new TrocaOleo("ABC1D23", 50.0, "5W30", 4);

        troca.calcularOrcamentoFinal();

        assertEquals(190.0, troca.getOrcamentoFinal(), 0.001);
    }

    @Test
    public void testDiasGarantia() {
        TrocaOleo troca = new TrocaOleo("ABC1D23", 50.0, "5W30", 4);

        assertEquals(90, troca.obterDiasGarantia());
    }
}