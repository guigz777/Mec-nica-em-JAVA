package com.mecanica.model;
public abstract class OrdemServico implements Garantia {

    private String placaVeiculo;
    private double valorBase;

    public OrdemServico(String placaVeiculo, double valorBase) {
        setPlacaVeiculo(placaVeiculo);
        setValorBase(valorBase);
    }

    public String getPlacaVeiculo() {
        return placaVeiculo;
    }

    public void setPlacaVeiculo(String placaVeiculo) {
        this.placaVeiculo = placaVeiculo;
    }

    public double getValorBase() {
        return valorBase;
    }

    public void setValorBase(double valorBase) {
        if (valorBase < 0) {
            throw new IllegalArgumentException("O valor base não pode ser negativo."); // gpt tbm isso aq
        }
        this.valorBase = valorBase;
    }

    public abstract void calcularOrcamentoFinal();

    @Override
    public String toString() {
        return String.format("Placa: %s | Valor base: R$ %.2f", placaVeiculo, valorBase);
    }
}