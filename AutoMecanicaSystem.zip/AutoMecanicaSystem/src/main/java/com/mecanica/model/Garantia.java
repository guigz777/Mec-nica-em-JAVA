package com.mecanica.model;
public interface Garantia {

    void aplicarGarantia();
    int obterDiasGarantia();
}
