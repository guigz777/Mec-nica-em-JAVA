package com.mecanica.model;
public class TrocaOleo extends OrdemServico {
    
    private static final double CUSTO_POR_LITRO = 35.0;
    private String tipoOleo;
    private int litros;
    private double orcamentoFinal;
    
    public TrocaOleo(String placaVeiculo, double valorBase, String tipoOleo, int litros) {
        super(placaVeiculo, valorBase);
        this.tipoOleo = tipoOleo;
        this.litros = litros;
    }
    
    public String getTipoOleo() {
        return tipoOleo;
    }
    
    public void setTipoOleo(String tipoOleo) {
        this.tipoOleo = tipoOleo;
    }
    
   public int getLitros() {
        return litros;
    }
   
   public void setLitros(int litros) {
        this.litros = litros;
    }

    public double getOrcamentoFinal() {
        return orcamentoFinal;
    }

    @Override
    public void calcularOrcamentoFinal() {
        orcamentoFinal = getValorBase() + (litros * CUSTO_POR_LITRO);
        System.out.printf("Orçamento final da troca de óleo: R$ %.2f%n", orcamentoFinal);
    }

    @Override
    public void aplicarGarantia() {
        System.out.println("Garantia de troca de óleo aplicada: " + obterDiasGarantia() + " dias.");
    }

    @Override
    public int obterDiasGarantia() {
        return 90;
    }

    @Override
    public String toString() {
        return "Troca de Óleo - " + super.toString() + String.format(" | Óleo: %s | Litros: %d", tipoOleo, litros);
    }
}
