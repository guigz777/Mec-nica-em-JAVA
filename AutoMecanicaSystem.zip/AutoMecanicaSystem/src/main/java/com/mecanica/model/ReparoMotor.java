package com.mecanica.model;
public class ReparoMotor extends OrdemServico {
    
    private static final double VALOR_HORA = 80.0;
    private String grauComplexidade;
    private int horasTrabalhadas;
    private double orcamentoFinal;
    
    public ReparoMotor(String placaVeiculo, double valorBase, String grauComplexidade, int horasTrabalhadas) {
        super(placaVeiculo, valorBase);
        this.grauComplexidade = grauComplexidade;
        this.horasTrabalhadas = horasTrabalhadas;
    }

    public String getGrauComplexidade() {
        return grauComplexidade;
    }

    public void setGrauComplexidade(String grauComplexidade) {
        this.grauComplexidade = grauComplexidade;
    }

    public int getHorasTrabalhadas() {
        return horasTrabalhadas;
    }

    public void setHorasTrabalhadas(int horasTrabalhadas) {
        this.horasTrabalhadas = horasTrabalhadas;
    }

    public double getOrcamentoFinal() {
        return orcamentoFinal;
    }

    @Override
    public void calcularOrcamentoFinal() {
        double total = getValorBase() + (horasTrabalhadas * VALOR_HORA);
        if ("alta".equalsIgnoreCase(grauComplexidade)) { // GPT d+ essa parte kkk
            total *= 1.30;
        }
        orcamentoFinal = total;
        System.out.printf("Orçamento final do reparo de motor: R$ %.2f%n", orcamentoFinal);
    }

    @Override
    public void aplicarGarantia() {
        System.out.println("Garantia de reparo de motor aplicada: " + obterDiasGarantia() + " dias.");
    }

    @Override
    public int obterDiasGarantia() {
        return 180;
    }

    @Override
    public String toString() {
        return "Reparo de Motor -> " + super.toString() + String.format(" | Complexidade: %s | Horas: %d", grauComplexidade, horasTrabalhadas);
    }
}
