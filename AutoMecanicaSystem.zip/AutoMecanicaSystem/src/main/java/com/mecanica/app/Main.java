package com.mecanica.app;
import com.mecanica.model.OrdemServico;
import com.mecanica.model.ReparoMotor;
import com.mecanica.model.TrocaOleo;
import com.mecanica.service.OficinaService;
import java.util.Scanner;
public class Main {
    public static void main(String[] args) {
        Scanner leia = new Scanner(System.in);
        OficinaService service = new OficinaService();
        int opcao = 0;
        
        do {
            System.out.println("\n===== " + OficinaService.NOME_OFICINA + " =====");
            System.out.println("1 - Cadastrar nova Troca de Óleo");
            System.out.println("2 - Cadastrar novo Reparo de Motor");
            System.out.println("3 - Listar todas as Ordens de Serviço");
            System.out.println("4 - Exibir total de ordens criadas");
            System.out.println("0 - Sair do sistema");
            System.out.print("Escolha uma opção: ");
            
            try {
                opcao = Integer.parseInt(leia.nextLine());

                switch (opcao) {
                    case 1:
                        System.out.print("Placa do veículo: ");
                        String placaOleo = leia.nextLine();
                        System.out.print("Valor base (use ponto, ex: 80.50): ");
                        double baseOleo = Double.parseDouble(leia.nextLine());
                        System.out.print("Tipo de óleo: ");
                        String tipoOleo = leia.nextLine();
                        System.out.print("Quantidade de litros: ");
                        int litros = Integer.parseInt(leia.nextLine());

                        OrdemServico troca = new TrocaOleo(placaOleo, baseOleo, tipoOleo, litros);
                        service.adicionarOrdem(troca);
                        System.out.println("Troca de óleo cadastrada com sucesso!");
                        break;

                    case 2:
                        System.out.print("Placa do veículo: ");
                        String placaMotor = leia.nextLine();
                        System.out.print("Valor base (use ponto, ex: 300.00): ");
                        double baseMotor = Double.parseDouble(leia.nextLine());
                        System.out.print("Grau de complexidade (baixa/média/alta): ");
                        String complexidade = leia.nextLine();
                        System.out.print("Horas trabalhadas: ");
                        int horas = Integer.parseInt(leia.nextLine());

                        OrdemServico reparo = new ReparoMotor(placaMotor, baseMotor, complexidade, horas);
                        service.adicionarOrdem(reparo);
                        System.out.println("Reparo de motor cadastrado com sucesso!");
                        break;

                    case 3:
                        service.listarOrdens();
                        break;

                    case 4:
                        System.out.println("Total de ordens criadas: " + OficinaService.getTotalOrdensCriadas());
                        break;

                    case 0:
                        System.out.println("Encerrando o sistema. Até logo!");
                        break;

                    default:
                        System.out.println("Opção inválida. Tente novamente.");
                }
            } catch (NumberFormatException e) { // essa parte tbm 
                System.out.println("Entrada inválida: digite um número válido.");
                opcao = -1;
            } catch (IllegalArgumentException e) { // adivinha da onde veio essa kkkkk
                System.out.println("Erro: " + e.getMessage());
            }

        } while (opcao != 0);
    }
}
