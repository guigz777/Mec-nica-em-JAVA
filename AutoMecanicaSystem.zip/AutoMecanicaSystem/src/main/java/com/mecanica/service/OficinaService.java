package com.mecanica.service;
import com.mecanica.model.OrdemServico;
import java.util.ArrayList;
import java.util.List;

public class OficinaService {
    public static final String NOME_OFICINA = "CGR";
    private static int totalOrdensCriadas = 0;
    private List<OrdemServico> ordens = new ArrayList<>();
    
    public void adicionarOrdem(OrdemServico ordem) {
        ordens.add(ordem);
        totalOrdensCriadas++;
    }

    public void listarOrdens() {
        if (ordens.isEmpty()) {
            System.out.println("Nenhuma ordem de serviço cadastrada.");
            return;
        }

        for (OrdemServico ordem : ordens) { 
            System.out.println(ordem);
            ordem.calcularOrcamentoFinal();
            System.out.println("-----------------------------");
        }
    }

    public static int getTotalOrdensCriadas() {
        return totalOrdensCriadas;
    }
}